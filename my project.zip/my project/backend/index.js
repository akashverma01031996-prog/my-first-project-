const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Backend server is running!');
});

app.listen(PORT, () => {
  console.log(`Server listening at http://localhost:${PORT}`);
});

// ...aapka upar wala code yahi rehne de

// Ye naya route hai video generate karne ke liye
app.post('/generate-video', (req, res) => {
  const { text, avatar } = req.body;

  // Normally yahan AI API call hogi, ab dummy response dete hain
  console.log('User Input:', text, avatar);
  
  // Dummy video link (You can use any video link)
  const videoUrl = "https://www.w3schools.com/html/mov_bbb.mp4";

  res.json({ success: true, videoUrl, message: "Demo video ban gayi!" });
});