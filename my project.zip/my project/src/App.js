import React, { useState } from 'react';

function App() {
  const [text, setText] = useState('');
  const [avatar, setAvatar] = useState('avatar1.png');
  const [backendMsg, setBackendMsg] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Avatars ki list
  const avatars = [
    { name: 'Avatar 1', file: 'avatar1.png' },
    { name: 'Avatar 2', file: 'avatar2.png' },
    { name: 'Avatar 3', file: 'avatar3.png' },
    { name: 'Avatar 4', file: 'avatar4.png' },
  ];

  // Backend se message lana
  const fetchBackendMessage = async () => {
    try {
      const response = await fetch('http://localhost:5000/');
      const text = await response.text();
      setBackendMsg(text);
    } catch (err) {
      setBackendMsg('Kuch galat ho gaya!');
    }
  };

  // Voice preview (browser ka built-in speech synthesis)
  const handleVoicePreview = () => {
    if ('speechSynthesis' in window) {
      const utter = new window.SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utter);
    } else {
      alert("Sorry, browser speech synthesis support nahi karta.");
    }
  };

  // Video generate API call
  const handleGenerateVideo = async () => {
    try {
      setIsLoading(true);
      setVideoUrl(''); // reset previous video
      const response = await fetch('http://localhost:5000/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, avatar }),
      });
      const data = await response.json();
      if (data.success) {
        setVideoUrl(data.videoUrl);
      } else {
        alert('Video banane mein error aayi!');
      }
    } catch (err) {
      alert('Server se connect nahi ho paaya!');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{
      maxWidth: 430,
      margin: '40px auto',
      borderRadius: 12,
      boxShadow: '0 3px 24px #bad1ff99',
      background: '#f6f9ff',
      padding: 30,
      textAlign: 'center',
      fontFamily: 'Arial',
    }}>
      <h1 style={{color:'#252c60'}}>HeyGen Clone</h1>
      {/* API Test Button */}
      <button onClick={fetchBackendMessage} style={{ marginBottom: 12 }}>Backend se hello bolo</button>
      <div style={{ margin: 10, color: 'green' }}>{backendMsg}</div>

      {/* Text Input + Character Count */}
      <input
        type="text"
        maxLength={200}
        placeholder="Yahan aapka text likhiye (max 200 char)..."
        value={text}
        onChange={e => setText(e.target.value)}
        style={{ width: '90%', padding: '10px', marginBottom: '4px', fontSize: 16 }}
      />
      <div style={{ fontSize: 12, color: "#696" }}>{text.length}/200</div>

      {/* Text-to-speech Preview */}
      <button onClick={handleVoicePreview} style={{margin:"6px 0 18px 0",fontSize:13}}>Voice Preview</button>

      {/* Avatar Gallery with Select */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 15, gap: 20 }}>
        {avatars.map(av => (
          <div key={av.file} style={{ cursor:'pointer', textAlign:'center' }}>
            <img
              src={av.file}
              alt={av.name}
              width={70}
              height={70}
              style={{
                border: avatar === av.file ? '3px solid #007bfa' : '2px solid #ccdaf7',
                borderRadius: '50%',
                boxShadow: avatar === av.file ? '0 0 12px #82afffcf' : '',
              }}
              onClick={() => setAvatar(av.file)}
            />
            <br />
            <input
              type="radio"
              name="avatar"
              value={av.file}
              checked={avatar === av.file}
              onChange={() => setAvatar(av.file)}
            />{' '}
            {av.name}
          </div>
        ))}
      </div>

      {/* Big Avatar Preview */}
      <img
        src={avatar}
        alt="Avatar"
        style={{
          width: 120,
          height: 120,
          marginBottom: 20,
          border: '3px solid #555',
          borderRadius: '50%',
          boxShadow: '0 0 10px #aaf',
        }}
      />

      {/* Generate Button + Loader */}
      <br />
      <button
        style={{ padding: '10px 30px', fontSize: 16, marginTop: '15px' }}
        onClick={handleGenerateVideo}
        disabled={isLoading}
      >
        {isLoading ? "Generating Video..." : "Generate Video"}
      </button>
      {isLoading && <div style={{marginTop:8}}>Loading... ⏳</div>}

      {/* Video Preview and Download Button */}
      {videoUrl && (
        <div style={{ marginTop: 20 }}>
          <h4>Generated Video:</h4>
          <video src={videoUrl} controls width="100%" />
          <div style={{ marginTop: 10 }}>
            <a href={videoUrl} download="heygen_demo.mp4">
              <button>Download Video</button>
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;